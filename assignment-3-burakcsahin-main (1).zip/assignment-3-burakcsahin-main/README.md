# assignment-3
Assignment 3 for Fall 2022 semester

You can find 4 test input files and their outputs for verification. Note that we may test your code on different examples, so your code must generalize.

Check the assignment pdf for more info.
